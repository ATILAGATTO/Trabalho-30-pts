<?php
include_once 'config/constantes.php';
include_once 'config/conexao.php';
include_once 'func/funcoes.php';

?>

<!doctype html>
<html lang="pt-br">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Entrar</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <link href="./css/atila.css" rel="stylesheet">
</head>

<body class="bg-dark text-white">

  <div class="container-fluid mb-5 shadow bg-dark" style="width: 400px; padding-top:50px; margin-top: 150px; padding:12px; border-radius: 25px; border: 1px solid rgba(255, 193, 7, 1);">
    <h2 class="text-white text-center">Login</h2>
    <form class="mt-4" name='devnautas' action="#" method="post" id="loginform">
      <div class="mb-3">
        <label for="nome" class="form-label  fs-5">Nome</label>
        <input type="text" class="form-control" id="nome" name="nome" placeholder="Digite um nome:">
      </div>
      <div class="mb-3">
        <label for="senha" class="form-label  fs-5">Digite a  senha</label>
        <input type="password" class="form-control" id="senha" name="senha" placeholder="Digite uma senha forte:">
      </div>
      <div class="alert alert-danger text-center" style="display:none;" role="alert" id="erromsg"></div>
      <div class="d-grid gap-2 d-md-flex justify-content-md-end">
        <button type="button" class="btn btn-outline-warning " onclick="fazerlogin()">Entrar</button>
      </div>
    </form>
  </div>
  <div class="text-center mt-5">
    <p>Não tem uma conta? <a href="cadastro.php" class="link-underline-warning text-warning">Cadastre-se</a></p>
  </div>

  <script src="./js/login.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

</body>

</html>