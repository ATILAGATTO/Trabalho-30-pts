<?php
include_once 'config/constantes.php';
include_once 'config/conexao.php';
include_once 'func/funcoes.php';

$controle = filter_input(INPUT_POST, 'controle', FILTER_SANITIZE_STRING);




if (isset($controle) && !empty('$controle')) {
    switch ($controle) {

        case 'formoso';
            include_once 'formoso.php';
            break;

        case 'listarproduto';
            include_once 'produto.php';
            break;

        case 'listaradm';
            include_once 'administrador.php';
            break;

        case 'contato';
            include_once 'contato.php';
            break;

        case 'listarbanner';
            include_once 'banner.php';
            break;

        case 'excProduto';
            include_once 'produtoexcluir.php';
            break;

        case 'excAdm';
            include_once 'excadm.php';
            break;

        case 'exccont';
            include_once 'exccont.php';
            break;

        case 'bannerexc';
            include_once 'bannerexc.php';
            break;

        case 'produtoadd';
            include_once 'produtoadd.php';
            break;


        case 'produtoalt';
            include_once 'produtoalt.php';
            break;

        case 'admadd';
            include_once 'administradoradd.php';
            break;

        case 'admAlt';
            include_once 'administradoralt.php';
            break;

        case 'banneradd';
            include_once 'banneradd.php';
            break;

        case 'banneralt';
            include_once 'banneralt.php';
            break;


        case 'excpedido';
            include_once 'excpedido.php';
            break;







        default:
            echo 'Pagina nao encontrada';
    }
}





//
//$acao = filter_input(INPUT_POST,'acao',FILTER_SANITIZE_STRING);
//
//$acaoid = filter_input(INPUT_POST,'acaoid',FILTER_SANITIZE_NUMBER_INT);
//
//$controle = filter_input(INPUT_POST,'controle',FILTER_SANITIZE_STRING);
//
//$controleGet = filter_input(INPUT_GET,'controleGet',FILTER_SANITIZE_STRING);
//
//switch ($acao){
//
//
//};
//
//
//switch ($controle){
//        case 'listarCliente';
//        include_once 'cliente.php';
//        break;
//            case 'listarGenero';
//                include_once 'genero.php';
//                break;
//                    case 'listarFilme';
//                        include_once 'filme.php';
//                        break;
//
//
//};
