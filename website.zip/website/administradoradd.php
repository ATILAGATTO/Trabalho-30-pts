<?php
include_once 'config/constantes.php';
include_once 'config/conexao.php';
include_once 'func/funcoes.php';


$conn = conectar();

$dados = filter_input_array(INPUT_POST, FILTER_DEFAULT);

// echo json_encode($dados);

if (!empty($dados)  && isset($dados) ){
$nomeadm = isset($dados["nomea"]) ? addslashes(mb_strtoupper($dados["nomea"], 'UTF-8')) : '';
$telefoneadm = isset($dados["telefonea"]) ? addslashes(mb_strtoupper($dados["telefonea"], 'UTF-8')) : '';
$senhaadm = isset($dados["senhaA"]) ? addslashes(mb_strtoupper($dados["senhaA"], 'UTF-8')) : '';

$options = [
    'cost' => 12,
];

$senhahash = password_hash($senhaadm, PASSWORD_BCRYPT, $options);

$retornoInsert = insertclienteid('adm', 'nome, telefone, senha',"$nomeadm", "$telefoneadm", "$senhahash" );
if ($retornoInsert > 0) {
    echo json_encode(['success' => true, 'message' => "Cliente $nomeadm cadastrado com sucesso"]);

}else {
    echo json_encode(['success' => false, 'message' => "Cliente não cadastrado ! ErroR Bd"]);

}
}else {
    echo json_encode(['success' => false, 'message' => "Cliente não cadastrado! Error Variável"]);
}



?>