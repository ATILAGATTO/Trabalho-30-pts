<?php
include_once 'config/constantes.php';
include_once 'config/conexao.php';
include_once 'func/funcoes.php';

if ($_SESSION['idadm']) {
  $idUsuarioSession = $_SESSION['idadm'];
} else {
  session_destroy();
  header('location: ./index.php');
  die();
}
?>

<head>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <link href="https://fonts.googleapis.com/css2?family=Lato&display=swap" rel="stylesheet">
  <link href="https://use.fontawesome.com/releases/v5.6.1/css/all.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <link rel="stylesheet" href="css/dash.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Kanit:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
</head>

<body class="kanit-regular bg-dark">
  <input type="checkbox" id="check">
  <label for="check">
    <i class="fas fa-bars" id="btn"></i>
    <i class="fas fa-times" id="cancel"></i>
  </label>
  <div class="sidebar bg-black">
    <header class="bg-black">Menu</header>
    <a onclick="carregarConteudo('listarproduto')" href="#" style="text-decoration:none;">
      <i class="bi bi-archive"></i>
      <span>Produto</span>
    </a>
    <a onclick="carregarConteudo('listaradm')" href="#" style="text-decoration:none;">
      <i class="bi bi-person-fill-gear"></i>
      <span>Adm</span>
    </a>
    <a onclick="carregarConteudo('contato')" href="#" style="text-decoration:none;">
      <i class="bi bi-telephone"></i>
      <span class="link">Contato</span>
    </a>
    <a onclick="carregarConteudo('listarbanner')" href="#" style="text-decoration:none;">
      <i class="bi bi-images"></i>
      <span>Banner</span>
    </a>
    <a href="indes.php" style="text-decoration:none;">
      <i class="bi bi-arrow-left-square"></i>
      <span class="link">página de início</span>
    </a>
    <a href="logout.php" style="text-decoration:none;">
      <i class="bi bi-box-arrow-left"></i>
      <span class="link">Sair</span>
    </a>


  </div>
</body>

<div class="frame" id="conteudo">
  <h2 class="colorir kanit-teste">Bem vindo adm</h2>
  <p id="time" class="colorir2"></p>




</div>
<!-- Modal  de Cadastro de produto-->

<div class="modal fade" id="modalAddproduto" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="staticBackdropLabel">Adicionar Produto <i class="bi bi-dropbox"></i></h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form name="frmAddproduto" id="frmAddproduto" action="#" method="post">
          <div class="mb-3">
            <label for="idnomep" class="form-label">Nome</label>
            <input type="text" class="form-control" name="nomep" id="idnomep" aria-describedby="emailHelp" required=required>

            <div>
              <div class="mb-4 d-flex justify-content-center mt-3">
               <label for="idfotop"> <img id="selectedImage" src="./img/sem foto.png" style="width: 300px;" /></label>
              </div>
              <div class="d-flex justify-content-center">
                <div data-mdb-ripple-init class="btn btn-primary btn-rounded">
                  <label class="form-label text-white m-1" for="idfotop">Selecione a foto</label>
                  <input type="file" class="form-control d-none" id="idfotop" onchange="displaySelectedImage(event, 'selectedImage')" />
                </div>
              </div>
            </div>
            <label for="idprecop" class="form-label">Preço</label>
            <input type="text" class="form-control" name="precop" id="idprecop" aria-describedby="emailHelp" required=required>
            <label for="iddesc" class="form-label">Descrição</label>
            <input type="text" class="form-control" name="descp" id="iddesc" aria-describedby="emailHelp" required=required>


          </div>

          <button type="submit" id="btnAddproduto" class="btn btn-primary">Adicionar</button>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>

      </div>
    </div>
  </div>
</div>


<!-- Modal  de editar produto-->

<div class="modal fade" id="modaleditproduto" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="staticBackdropLabel">Editar Produto <i class="bi bi-dropbox"></i></h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form name="frmeditproduto" id="frmeditproduto" action="#" method="post">
          <div class="mb-3">
            <label for="idnomepedit" class="form-label">Nome</label>
            <input type="text" class="form-control" name="nomepedit" id="idnomepedit" aria-describedby="emailHelp" required=required>
            <div>
              <div class="mb-4 d-flex justify-content-center mt-3">
              <label for="idfotopedit"> <img id="selectedImage" src="./img/sem foto.png" style="width: 300px;" /></label> 
              </div>
              <div class="d-flex justify-content-center">
                <div data-mdb-ripple-init class="btn btn-primary btn-rounded">
                  <label class="form-label text-white m-1" for="idfotopedit">Selecione a foto</label>
                  <input type="file" class="form-control d-none" id="idfotopedit" onchange="displaySelectedImage(event, 'selectedImage')" />
                </div>
              </div>
            </div>
            <label for="idprecopedit" class="form-label">Preço</label>
            <input type="text" class="form-control" name="precopedit" id="idprecopedit" aria-describedby="emailHelp" required=required>
            <label for="iddescedit" class="form-label">Descrição</label>
            <input type="text" class="form-control" name="descpedit" id="iddescedit" aria-describedby="emailHelp" required=required>

            <input type="hidden" class="form-control mt-3" name="idprodutoedit" id="idprodutoedit2" aria-describedby="emailHelp">


          </div>

          <button type="submit" id="btneditproduto" class="btn btn-primary">Adicionar</button>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>

      </div>
    </div>
  </div>
</div>


<!-- Modal  de Cadastro de adm-->

<div class="modal fade" id="modalAddadm" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="staticBackdropLabel">Adicionar adm <i class="bi bi-person-fill-gear"></i></h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form name="frmAddadm" id="frmAddadm" action="#" method="post">
          <div class="mb-3">
            <label for="idnomea" class="form-label">Nome</label>
            <input type="text" class="form-control" name="nomea" id="idnomea" aria-describedby="emailHelp" required=required>
            <label for="idtelefonea" class="form-label">Telefone</label>
            <input type="text" class="form-control" name="telefonea" id="idtelefonea" aria-describedby="emailHelp" required=required>
            <label for="idsenhaA" class="form-label">Senha</label>
            <input type="password" class="form-control" name="senhaA" id="idsenhaA" aria-describedby="emailHelp" required=required>



          </div>

          <button type="submit" id="btnAddadm" class="btn btn-primary">Adicionar</button>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>

      </div>
    </div>
  </div>
</div>

<!-- Modal  de editar  adm-->

<div class="modal fade" id="modaleditadm" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="staticBackdropLabel">Editar adm <i class="bi bi-person-fill-gear"></i></h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form name="frmeditadm" id="frmeditadm" action="#" method="post">
          <div class="mb-3">
            <label for="idnomeaedit" class="form-label">Nome</label>
            <input type="text" class="form-control" name="nomeaedit" id="idnomeaedit" aria-describedby="emailHelp" required=required>
            <label for="idtelefoneaedit" class="form-label">Telefone</label>
            <input type="text" class="form-control" name="telefoneaedit" id="idtelefoneaedit" aria-describedby="emailHelp" required=required>
            <label for="idsenhaAedit" class="form-label">Senha</label>
            <input type="password" class="form-control" name="senhaAedit" id="idsenhaAedit" aria-describedby="emailHelp" required=required>

            <input type="hidden" class="form-control mt-3" name="idadmedit" id="idadmedit2" aria-describedby="emailHelp">


          </div>

          <button type="submit" id="btneditadm" class="btn btn-primary">Adicionar</button>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>

      </div>
    </div>
  </div>
</div>


<!-- Modal  de Cadastro de banner-->

<div class="modal fade" id="modalAddbanner" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="staticBackdropLabel">Adicionar banner <i class="bi bi-image"></i></h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form name="frmAddbanner" id="frmAddbanner" action="#" method="post">
          <div class="mb-3">
          <div>
              <div class="mb-4 d-flex justify-content-center mt-3">
                <label for="idfotob"><img id="selectedImage" src="./img/sem foto.png" style="width: 300px;" /></label>
              </div>
              <div class="d-flex justify-content-center">
                <div data-mdb-ripple-init class="btn btn-primary btn-rounded">
                  <label class="form-label text-white m-1" for="idfotob">Selecione a foto</label>
                  <input type="file" class="form-control d-none" id="idfotob" onchange="displaySelectedImage(event, 'selectedImage')" />
                </div>
              </div>
            </div>



          </div>

          <button type="submit" id="btnAddbanner" class="btn btn-primary">Adicionar</button>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>

      </div>
    </div>
  </div>
</div>


<!-- Modal  de Editar banner-->

<div class="modal fade" id="modalEditbanner" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="staticBackdropLabel">Editar banner <i class="bi bi-image"></i></h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form name="frmEditbanner" id="frmEditbanner" action="#" method="post">
          <div class="mb-3">

          <div>
              <div class="mb-4 d-flex justify-content-center mt-3">
                <label for="idfotobedit"><img id="selectedImage" src="./img/sem foto.png" style="width: 300px;" /></label>
              </div>
              <div class="d-flex justify-content-center">
                <div data-mdb-ripple-init class="btn btn-primary btn-rounded">
                  <label class="form-label text-white m-1" for="idfotobedit">Selecione a foto</label>
                  <input type="file" class="form-control d-none" id="idfotobedit" onchange="displaySelectedImage(event, 'selectedImage')" />
                </div>
              </div>
            </div>
            <input type="hidden" class="form-control" name="idbanner" id="idbanner2" aria-describedby="emailHelp" required=required>


          </div>

          <button type="submit" id="btneditbanner" class="btn btn-primary">Adicionar</button>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>

      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
<script src="js/func.js"></script>
<script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.js"></script>

<script>
   $('#idtelefonea').mask('(00) 00000-0000');
</script>

<script>
   $('#idtelefoneaedit').mask('(00) 00000-0000');
</script>
<script>
    const avatarImage = document.querySelector('#avatar-image');
    const h2Avatar = document.querySelector('#h2-avatar');

    avatarImage.addEventListener('change', event => {
      const preview = document.querySelector('#preview-image');

      if (preview) {
        preview.remove();
      }

      const reader = new FileReader;

      reader.onload = function(event) {
        const previewImage = document.createElement('img');
        previewImage.width = 115;
        previewImage.height = 100;
        previewImage.id = 'preview-image';
        previewImage.src = event.target.result;
        h2Avatar.insertAdjacentElement('afterend', previewImage);
      }

      reader.readAsDataURL(avatarImage.files[0]);

    })
  </script>
<script>
  var timeDisplay = document.getElementById("time");


  function refreshTime() {
    var dateString = new Date().toLocaleString("pt-BR", {
      timeZone: "America/Sao_Paulo"
    });
    var formattedString = dateString.replace(", ", " - ");
    timeDisplay.innerHTML = formattedString;
  }

  setInterval(refreshTime, 1000);
</script>



</body>