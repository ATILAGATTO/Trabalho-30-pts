<?php
include_once 'config/constantes.php';
include_once 'config/conexao.php';
include_once 'func/funcoes.php';
$conn = conectar();

$dados = filter_input_array(INPUT_POST, FILTER_DEFAULT);
// echo json_encode($dados);

if (isset($dados) && !empty($dados)) {
    $nome = isset($dados["nomeAdd"]) ? addslashes($dados["nomeAdd"]) : '';
    $tel = isset($dados["whatsappAdd"]) ? addslashes($dados["whatsappAdd"]) : '';
    $senha = isset($dados["senhaAdd"]) ? addslashes($dados["senhaAdd"]) : '';
    $senhaHash = password_hash($senha, PASSWORD_BCRYPT);
   
    $retornoInsert = insertTresId('cliente', 'nome, telefone, senha', "$nome", "$tel", "$senhaHash");
    if ($retornoInsert) {
        echo json_encode(['success' => true, 'message' => "Usuário $nome cadastro com sucesso"]);
    } else {
        echo json_encode(['success' => false, 'message' => "Usuário não cadastrado! ErroR 8d"]);
    }
} else {
    echo json_encode(['success' => false, 'message' => "Usuário não cadastrado! ErroR variável"]);
}


echo '<script>alert("Cliente cadastrado com sucesso!"); window.location.href = "index.php";</script>';
?>