<?php
include_once 'config/constantes.php';
include_once 'config/conexao.php';
include_once 'func/funcoes.php';


$dados = filter_input_array(INPUT_POST, FILTER_DEFAULT);


if (!empty($dados)  && isset($dados) ){
    
    $idadm = isset($dados["id"]) ? intval($dados["id"]) : 0;
    
    $retornodelete = deletarRegistro('adm', 'idadm', $idadm);


 if ($retornodelete > 0) {
    echo json_encode(['success' => true, 'message' => "Genero excluido com sucesso"]);

 }else {
     echo json_encode(['success' => false, 'message' => "Genero não excluido ! ErroR Bd"]);

 }
 }else {
     echo json_encode(['success' => false, 'message' => "Genero não excluiu! Error Variável"]);
 }


?>