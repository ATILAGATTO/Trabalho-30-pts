<?php
include_once 'config/constantes.php';
include_once 'config/conexao.php';
include_once 'func/funcoes.php';


$conn = conectar();

$dados = filter_input_array(INPUT_POST, FILTER_DEFAULT);

// echo json_encode($dados);

if (!empty($dados)  && isset($dados) ){
$nomeadmedit = isset($dados["nomeaedit"]) ? addslashes(mb_strtoupper($dados["nomeaedit"], 'UTF-8')) : '';
$telefoneadmedit = isset($dados["telefoneaedit"]) ? addslashes(mb_strtoupper($dados["telefoneaedit"], 'UTF-8')) : '';
$senhaadmedit = isset($dados["senhaAedit"]) ? addslashes(mb_strtoupper($dados["senhaAedit"], 'UTF-8')) : '';
$idadmedit = isset($dados["idadmedit"]) ? addslashes(mb_strtoupper($dados["idadmedit"], 'UTF-8')) : '';

$options = [
    'cost' => 12,
];

$senhahash = password_hash($senhaadmedit, PASSWORD_BCRYPT, $options);

$retornoInsert = updatecliente('adm', 'nome', 'telefone', 'senha', 'idadm',"$nomeadmedit", "$telefoneadmedit", "$senhahash", "$idadmedit" );
if ($retornoInsert > 0) {
    echo json_encode(['success' => true, 'message' => "Cliente $nomeadmedit cadastrado com sucesso"]);

}else {
    echo json_encode(['success' => false, 'message' => "Cliente não cadastrado ! ErroR Bd"]);

}
}else {
    echo json_encode(['success' => false, 'message' => "Cliente não cadastrado! Error Variável"]);
}



?>