<?php
include_once 'config/constantes.php';
include_once 'config/conexao.php';
include_once 'func/funcoes.php';

$conn = conectar();

$dados = filter_input_array(INPUT_POST, FILTER_DEFAULT);

$nome = $dados['nome'];
$senha = $dados['senha'];

$retornoValidar = validarSenhaCriptogtografia('idadm, nome, telefone, cadastro, alteracao, ativo, senha', 'adm', 'nome', 'senha', "$nome", "$senha", 'ativo', 'A');

if ($retornoValidar) {
  if ($retornoValidar == 'usuario') {
    echo json_encode(['success' => false, 'message' => 'Usuário inválido']);
  } else if ($retornoValidar == 'telefone') {
    echo json_encode(['success' => false, 'message' => 'Telefone incorreto']);
  } else {
    $_SESSION['idadm'] = $retornoValidar->idadm;
    echo json_encode(['success' => true, 'message' => 'Login efetuado com sucesso! Redirecionando']);
  }
} else {
  echo json_encode(['success' => false, 'message' => 'Nome ou senha inválidos']);
}