<?php
include_once 'config/constantes.php';
include_once 'config/conexao.php';
include_once 'func/funcoes.php';
$conn = conectar();

$dados = filter_input_array(INPUT_POST, FILTER_DEFAULT);

// echo json_encode($dados);

$idedit = $dados["idbanner"];


if (isset($_FILES['foto']) && $_FILES['foto']['error'] == UPLOAD_ERR_OK) {
   $fotoTmpNome = $_FILES['foto']['tmp_name'];
   $fotoName = $_FILES['foto']['name'];
   $uploadDir = 'img';
   $fotobathedit = uniqid() . '_' . $fotoName;
   if (move_uploaded_file($fotoTmpNome, $uploadDir . '/' . $fotobathedit)) {

      $retornoInsert = updatebanner('banner', 'foto',  "$fotobathedit",'idbanner', "$idedit");

      if ($retornoInsert > 0) {
         echo json_encode(['success' => true, 'message' => "Carro cadastrado com sucesso"]);
      } else {
         echo json_encode(['success' => false, 'message' => "Carro não cadastrado ! ErroR Bd"]);
      }
   } else {
      echo json_encode(['success' => false, 'message' => "Carro não cadastrado! Error Variável"]);
   }
}
