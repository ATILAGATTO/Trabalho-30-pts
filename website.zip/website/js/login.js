if (document.getElementById("nome")) {
    document.getElementById("nome").focus();
}


function fazerlogin() {

    var nome = document.getElementById("nome").value;
    var whatsapp = document.getElementById("whatsapp").value;
    var senha = document.getElementById("senha").value;
    var erromsg = document.getElementById("erromsg");

    if (nome === '') {
        erromsg.style.display = 'block';
        erromsg.innerHTML = 'O campo de nome está vazio.Por favor preencha o nome.';
        return;
    }
    else if (whatsapp === '') {
        erromsg.style.display = 'block';
        erromsg.innerHTML = 'O campo de contato está vazio.Por favor preencha o contato.';
        return;
    } else if (senha === '') {
        erromsg.style.display = 'block';
        erromsg.innerHTML = 'O campo de senha está vazio.Por favor preencha a senha.';
        return;
    } else if (senha.length < 8) {
        erromsg.style.display = 'block';
        erromsg.innerHTML = 'A senha deve conter 8 dígitos';
        return;
    } else {
        erromsg.style.display = 'none';
    }
    fetch('php.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: 'nome=' + encodeURIComponent(nome) + '&whatsapp=' + encodeURIComponent(whatsapp) + '&senha=' + encodeURIComponent(senha),
    })
        .then(response => response.json())
        .then(data => {
            console.log(data.message);

            if (data.success) {
                // alert(data.message);
                erromsg.classList.remove('alert-danger');
                erromsg.classList.add('alert-success');
                erromsg.innerHTML = data.message;
                erromsg.style.display = 'block';

                setTimeout(function () {
                    window.location.href = 'index.php';
                }, 2000);
            } else {
                erromsg.style.display = 'block';
                erromsg.innerHTML = data.message;
            }
        })
        .catch(error => {
            console.error('Erro na requisição', error);
        });
}

// function mostrarProcessando() {
//     var divProcessando = document.createElement('div');
//     divProcessando.id = 'processandoDiv';
//     divProcessando.style.position = 'fixed';
//     divProcessando.style.top = '47%';
//     divProcessando.style.left = '50%';
//     divProcessando.style.transform = 'translate(-50%, -50%)';
//     divProcessando.innerHTML = '<img src="./img/processando.gif"  width="300px" alt="Processando.." title="Processando..">';
//     document.body.appendChild(divProcessando);
// };

// function esconderProcessando() {
//     var divProcessando = document.getElementById('processandoDiv');
//     if (divProcessando) {
//         document.body.removeChild(divProcessando);
//     }
// };

// function carregarConteudo(controle) {
//     fetch('controle.php', {
//         method: 'POST',
//         headers: {
//             'content-type': 'application/x-www-form-urlencoded',
//         },
//         body: 'controle=' + encodeURIComponent(controle),
//     })
//         .then(response => response.text())
//         .then(data => {
//             document.getElementById('conteudo').innerHTML = data;
//         })
//         .catch(error => console.error('Erro na requisiçao'))
// }