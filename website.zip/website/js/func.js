function carregarConteudo(controle) {
    fetch('controle.php', {
        method: 'POST',
        headers: {
            'content-type': 'application/x-www-form-urlencoded',
        },
        body: 'controle=' + encodeURIComponent(controle),
    })
        .then(response => response.text())
        .then(data => {
            document.getElementById('conteudo').innerHTML = data;
        })
        .catch(error => console.error('Erro na requisiçao'))
};






const produtoModalFechar = new bootstrap.Modal(
    document.getElementById('modalAddproduto')
);

const produtoModaleditFechar = new bootstrap.Modal(
    document.getElementById('modaleditproduto')
);

const admModaleditFechar = new bootstrap.Modal(
    document.getElementById('modaleditadm')
);


const bannerModalfechar = new bootstrap.Modal(
    document.getElementById('modalAddbanner')
);

const bannerModaleditFechar = new bootstrap.Modal(
    document.getElementById('modalEditbanner')
);







const produtoModal = document.getElementById('modalAddproduto');
const innomep = document.getElementById('idnomep');
const btnaddp = document.getElementById('btnAddproduto');

    if (produtoModal) {

    const formproduto = document.getElementById('frmAddproduto');

    produtoModal.addEventListener('shown.bs.modal', () => {
        innomep.focus();
        const submitHandler = function (event) {
            event.preventDefault();
            // btnaddCarro.disabled = true;


            var form = event.target;
            var formData = new FormData(form);
            formData.append('controle', 'produtoadd');
            var fileInput = document.getElementById('idfotop');
            formData.append('foto', fileInput.files[0]);

            formproduto.addEventListener('submit', submitHandler);

            fetch('controle.php', {
                method: 'POST',
                body: formData,
            })
                .then((response) => response.json())
                .then((data) => {
                    console.log(data);
                    if (data.success) {
                        // btnaddCarro.disabled = false;
                        produtoModalFechar.hide();
                        setTimeout(function () {
                            carregarConteudo('listarproduto');
                            esconderProcessando();
                        })
                        form.removeEventListener('submit', submitHandler);
                        alert('cadastrado com sucesso!');
                    } else {
                        alert('erro no cadastro!');
                    }
                })
                .catch(error => {
                    console.error('Erro na requisição:', error);
                });
        };
        formproduto.addEventListener('submit', submitHandler);
    })
};




function compra(){
    alert('Produto comprado!')
}














function deletargeral(controle, id) {

    fetch('controle.php', {
        method: 'POST',
        headers: {
            'content-type': 'application/x-www-form-urlencoded',
        },
        body: 'controle=' + encodeURIComponent(controle) + '&id=' + encodeURIComponent(id)
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                carregarConteudo('listargenero')
            }
        })
        .catch(error => console.error('Erro na requisiçao'))
};



function deletargeral2(controle, id) {

    fetch('controle.php', {
        method: 'POST',
        headers: {
            'content-type': 'application/x-www-form-urlencoded',
        },
        body: 'controle=' + encodeURIComponent(controle) + '&id=' + encodeURIComponent(id)
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                carregarConteudo('listarservicos')
            }
        })
        .catch(error => console.error('Erro na requisiçao'))
};



function deletargeraladm(controle, id) {

    fetch('controle.php', {
        method: 'POST',
        headers: {
            'content-type': 'application/x-www-form-urlencoded',
        },
        body: 'controle=' + encodeURIComponent(controle) + '&id=' + encodeURIComponent(id)
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                carregarConteudo('listaradm')
            }
        })
        .catch(error => console.error('Erro na requisiçao'))
};



function deletargeralcontato(controle, id) {

    fetch('controle.php', {
        method: 'POST',
        headers: {
            'content-type': 'application/x-www-form-urlencoded',
        },
        body: 'controle=' + encodeURIComponent(controle) + '&id=' + encodeURIComponent(id)
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                carregarConteudo('contato')
            }
        })
        .catch(error => console.error('Erro na requisiçao'))
};

function deletargeralbanner(controle, id) {

    fetch('controle.php', {
        method: 'POST',
        headers: {
            'content-type': 'application/x-www-form-urlencoded',
        },
        body: 'controle=' + encodeURIComponent(controle) + '&id=' + encodeURIComponent(id)
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                carregarConteudo('listarbanner')
            }
        })
        .catch(error => console.error('Erro na requisiçao'))
};


function deletargeralpedido(controle, id) {

    fetch('controle.php', {
        method: 'POST',
        headers: {
            'content-type': 'application/x-www-form-urlencoded',
        },
        body: 'controle=' + encodeURIComponent(controle) + '&id=' + encodeURIComponent(id)
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                carregarConteudo('listarpedido')
            }
        })
        .catch(error => console.error('Erro na requisiçao'))
};



document.getElementById('frmeditproduto').addEventListener('submit',function (event){
    event.preventDefault();
    alert('clicou no botão');
    var formData = new FormData(this);
                formData.append('controle', 'produtoalt');
                var fileInput = document.getElementById('idfotopedit');
                formData.append('foto', fileInput.files[0]);
    
            
    
                fetch('controle.php', {
                    method: 'POST',
                    body: formData,
                })
                    .then((response) => response.json())
                    .then(data => {
                        console.log(data);
                        if (data.success) {
                            carregarConteudo('listarproduto')
                            produtoModaleditFechar.hide();

                     }
                        
                        else {
                          
                        }
                    })
                    .catch(error => {
                        console.error('Erro na requisição:', error);
                    });
                });
    


function abrirModalEdicao2(nomepedit,precoedit,descricao,idprodutoedit){
var innomepedit = document.getElementById('idnomepedit');
var inprecoedit = document.getElementById('idprecopedit');
var indescriedit = document.getElementById('iddescedit');

if (nomepedit && precoedit && descricao ) {
    innomepedit.focus();
}
innomepedit.value = nomepedit
inprecoedit.value = precoedit
indescriedit.value = descricao
document.getElementById('idprodutoedit2').value = idprodutoedit

};













function deletargeralcliente(controle, id) {

    fetch('controle.php', {
        method: 'POST',
        headers: {
            'content-type': 'application/x-www-form-urlencoded',
        },
        body: 'controle=' + encodeURIComponent(controle) + '&id=' + encodeURIComponent(id)
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                carregarConteudo('listarproduto')
            }
        })
        .catch(error => console.error('Erro na requisiçao'))
};



const admModalFechar = new bootstrap.Modal(
    document.getElementById('modalAddadm')
);


const admModal = document.getElementById('modalAddadm');
const innomea = document.getElementById('idnomea');
const btnadda = document.getElementById('btnAddadm');

    if (admModal) {

    const formadm = document.getElementById('frmAddadm');

    admModal.addEventListener('shown.bs.modal', () => {
        innomea.focus();
        const submitHandler = function (event) {
            event.preventDefault();
            // btnaddCarro.disabled = true;


            var form = event.target;
            var formData = new FormData(form);
            formData.append('controle', 'admadd');

            formadm.addEventListener('submit', submitHandler);

            fetch('controle.php', {
                method: 'POST',
                body: formData,
            })
                .then((response) => response.json())
                .then((data) => {
                    console.log(data);
                    if (data.success) {
                        // btnaddCarro.disabled = false;
                        admModalFechar.hide();
                        setTimeout(function () {
                            carregarConteudo('listaradm');
                            esconderProcessando();
                        })
                        form.removeEventListener('submit', submitHandler);
                        alert('cadastrado com sucesso!');
                    } else {
                        alert('erro no cadastro!');
                    }
                })
                .catch(error => {
                    console.error('Erro na requisição:', error);
                });
        };
        formadm.addEventListener('submit', submitHandler);
    })
};




document.getElementById('frmeditadm').addEventListener('submit',function (event){
    event.preventDefault();
    alert('clicou no botão');
    var formData = new FormData(this);
                formData.append('controle', 'admAlt');
        

    
            
    
                fetch('controle.php', {
                    method: 'POST',
                    body: formData,
                })
                    .then((response) => response.json())
                    .then(data => {
                        console.log(data);
                        if (data.success) {
                            carregarConteudo('listaradm')
                            admModaleditFechar.hide();
                     }
                        
                        else {
                          
                        }
                    })
                    .catch(error => {
                        console.error('Erro na requisição:', error);
                    });
                });
    


function abrirModalEdicaoadm(nomeeditadm,telefoneedit,senhaedit,idadmedit){
var innomepeditadm = document.getElementById('idnomeaedit');
var intelefoneedit = document.getElementById('idtelefoneaedit');
var insenhaedit = document.getElementById('idsenhaAedit');

if (nomeeditadm && telefoneedit && senhaedit) {
    innomepeditadm.focus();
}
innomepeditadm.value = nomeeditadm
intelefoneedit.value = telefoneedit
insenhaedit.value = senhaedit
document.getElementById('idadmedit2').value = idadmedit

};




const bannerModal = document.getElementById('modalAddbanner');
const btnaddb = document.getElementById('btnAddbanner');

    if (bannerModal) {

    const formbanner = document.getElementById('frmAddbanner');

    bannerModal.addEventListener('shown.bs.modal', () => {
        const submitHandler = function (event) {
            event.preventDefault();
            // btnaddCarro.disabled = true;


            var form = event.target;
            var formData = new FormData(form);
            formData.append('controle', 'banneradd');
            var fileInput = document.getElementById('idfotob');
            formData.append('foto', fileInput.files[0]);

            formbanner.addEventListener('submit', submitHandler);

            fetch('controle.php', {
                method: 'POST',
                body: formData,
            })
                .then((response) => response.json())
                .then((data) => {
                    console.log(data);
                    if (data.success) {
                        // btnaddCarro.disabled = false;
                        bannerModalfechar.hide();
                        setTimeout(function () {
                            carregarConteudo('listarbanner');
                            esconderProcessando();
                        })
                        form.removeEventListener('submit', submitHandler);
                        alert('cadastrado com sucesso!');
                    } else {
                        alert('erro no cadastro!');
                    }
                })
                .catch(error => {
                    console.error('Erro na requisição:', error);
                });
        };
        formbanner.addEventListener('submit', submitHandler);
    })
};


document.getElementById('frmEditbanner').addEventListener('submit',function (event){
    event.preventDefault();
    alert('clicou no botão');
    var formData = new FormData(this);
                formData.append('controle', 'banneralt');
                var fileInput = document.getElementById('idfotobedit');
                formData.append('foto', fileInput.files[0]);
    
            
    
                fetch('controle.php', {
                    method: 'POST',
                    body: formData,
                })
                    .then((response) => response.json())
                    .then(data => {
                        console.log(data);
                        if (data.success) {
                            carregarConteudo('listarbanner')
                            bannerModaleditFechar.hide();

                     }
                        
                        else {
                          
                        }
                    })
                    .catch(error => {
                        console.error('Erro na requisição:', error);
                    });
                });
    


function abrirModaledicaobanner(idbanneredit){
document.getElementById('idbanner2').value = idbanneredit
};